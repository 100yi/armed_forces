from django.apps import AppConfig


class ArmedUniversitiesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'armed_universities'
